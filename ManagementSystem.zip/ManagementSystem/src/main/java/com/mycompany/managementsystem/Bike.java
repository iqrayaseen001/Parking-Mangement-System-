/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.managementsystem;

/**
 *
 * @author Jahan
 */
public class Bike extends Vehicle  {
   

    public Bike(String regNo) {
        super(regNo);
    }

    @Override
    public int calculateFee() {
        return getHours() * 50;
    }

    @Override
    public String getType() {
        return "Bike";
    }
}