/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.managementsystem;

/**
 *
 * @author Jahan
 */
public abstract class Vehicle {

    protected String regNo;
    protected long entryTime;

    public Vehicle(String regNo) {
        this.regNo = regNo;
        this.entryTime = System.currentTimeMillis();
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public long getEntryTime() {
        return entryTime;
    }

    public int getHours() {
        long diff = System.currentTimeMillis() - entryTime;
        int hours = (int) Math.ceil(diff / (1000.0 * 60 * 60));
        return Math.max(hours, 1);
    }

    public abstract int calculateFee();

    public abstract String getType();
}