/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.managementsystem;

/**
 *
 * @author Jahan
 */
    import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
public class ParkingSystem {



    private ArrayList<ParkingSlot> slots = new ArrayList<>();
    private int revenue = 0;
    private int totalParked = 0;

    public ParkingSystem(int size) {
        for (int i = 1; i <= size; i++) {
            slots.add(new ParkingSlot(i));
        }
    }

    // CREATE
    public String parkVehicle(Vehicle vehicle) {
        if (vehicle.getRegNo().trim().isEmpty()) {
            return "Please enter registration number";
        }

        if (isAlreadyParked(vehicle.getRegNo())) {
            return "Vehicle already parked";
        }

        for (ParkingSlot slot : slots) {
            if (!slot.isOccupied) {
                slot.isOccupied = true;
                slot.vehicle = vehicle;
                totalParked++;

                return "Vehicle parked successfully in Slot " + slot.id;
            }
        }

        return "Parking Full";
    }

    // READ ALL
    public String getStatus() {
        StringBuilder sb = new StringBuilder();

        sb.append("PARKING STATUS\n\n");

        for (ParkingSlot slot : slots) {
            sb.append("Slot ").append(slot.id).append(": ");

            if (slot.isOccupied && slot.vehicle != null) {
                sb.append(slot.vehicle.getType())
                        .append(" | Reg No: ")
                        .append(slot.vehicle.getRegNo())
                        .append(" | Hours: ")
                        .append(slot.vehicle.getHours());
            } else {
                sb.append("Free");
            }

            sb.append("\n");
        }

        sb.append("\nTotal Slots: ").append(slots.size());
        sb.append("\nOccupied Slots: ").append(getOccupiedSlots());
        sb.append("\nFree Slots: ").append(getFreeSlots());
        sb.append("\nTotal Vehicles Parked: ").append(totalParked);
        sb.append("\nRevenue: Rs. ").append(revenue);

        return sb.toString();
    }

    // READ ONE
    public String searchVehicle(String regNo) {
        if (regNo.trim().isEmpty()) {
            return "Please enter registration number";
        }

        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");

        for (ParkingSlot slot : slots) {
            if (slot.vehicle != null &&
                    slot.vehicle.getRegNo().equalsIgnoreCase(regNo.trim())) {

                return "Vehicle Found"
                        + "\nReg No: " + slot.vehicle.getRegNo()
                        + "\nType: " + slot.vehicle.getType()
                        + "\nSlot: " + slot.id
                        + "\nEntry Time: " + sdf.format(new Date(slot.vehicle.getEntryTime()))
                        + "\nCurrent Hours: " + slot.vehicle.getHours()
                        + "\nCurrent Fee: Rs. " + slot.vehicle.calculateFee();
            }
        }

        return "Vehicle Not Found";
    }

    // UPDATE
    public String updateVehicleRegNo(String oldRegNo, String newRegNo) {
        if (oldRegNo.trim().isEmpty() || newRegNo.trim().isEmpty()) {
            return "Please enter old and new registration number";
        }

        if (isAlreadyParked(newRegNo)) {
            return "New registration number already exists";
        }

        for (ParkingSlot slot : slots) {
            if (slot.vehicle != null &&
                    slot.vehicle.getRegNo().equalsIgnoreCase(oldRegNo.trim())) {

                slot.vehicle.setRegNo(newRegNo.trim());

                return "Registration number updated successfully";
            }
        }

        return "Vehicle Not Found";
    }

    // DELETE
    public String exitVehicle(String regNo) {
        if (regNo.trim().isEmpty()) {
            return "Please enter registration number";
        }

        for (ParkingSlot slot : slots) {
            if (slot.vehicle != null &&
                    slot.vehicle.getRegNo().equalsIgnoreCase(regNo.trim())) {

                int fee = slot.vehicle.calculateFee();
                revenue += fee;

                String message = "Vehicle Exited Successfully"
                        + "\nVehicle: " + slot.vehicle.getRegNo()
                        + "\nType: " + slot.vehicle.getType()
                        + "\nHours: " + slot.vehicle.getHours()
                        + "\nFee: Rs. " + fee
                        + "\nSlot freed: " + slot.id;

                slot.isOccupied = false;
                slot.vehicle = null;

                return message;
            }
        }

        return "Vehicle Not Found";
    }

    public int getRevenue() {
        return revenue;
    }

    public int getFreeSlots() {
        int count = 0;

        for (ParkingSlot slot : slots) {
            if (!slot.isOccupied) {
                count++;
            }
        }

        return count;
    }

    public int getOccupiedSlots() {
        return slots.size() - getFreeSlots();
    }

    private boolean isAlreadyParked(String regNo) {
        for (ParkingSlot slot : slots) {
            if (slot.vehicle != null &&
                    slot.vehicle.getRegNo().equalsIgnoreCase(regNo.trim())) {
                return true;
            }
        }

        return false;
    }
}