package com.mycompany.managementsystem;

import javax.swing.SwingUtilities;

public class ManagementSystem {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ParkingUI();
        });
    }
}