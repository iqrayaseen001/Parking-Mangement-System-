/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.managementsystem;

/**
 *
 * @author Jahan
 */
public class ParkingSlot {
    
    int id;
    boolean isOccupied;
    Vehicle vehicle;

    public ParkingSlot(int id) {
        this.id = id;
        this.isOccupied = false;
        this.vehicle = null;
    }
}