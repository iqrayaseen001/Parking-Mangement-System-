/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.managementsystem;

/**
 *
 * @author Jahan
 */
public class Car extends Vehicle {
    
    


    public Car(String regNo) {
        super(regNo);
    }

    @Override
    public int calculateFee() {
        return getHours() * 100;
    }

    @Override
    public String getType() {
        return "Car";
    }
}