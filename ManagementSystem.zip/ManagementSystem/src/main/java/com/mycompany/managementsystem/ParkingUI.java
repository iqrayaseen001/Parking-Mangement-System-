package com.mycompany.managementsystem;

import javax.swing.*;
import java.awt.*;

public class ParkingUI extends JFrame {

    private CardLayout layout;
    private JPanel mainPanel;

    private ParkingSystem system = new ParkingSystem(10);

    private JTextField regEntry;
    private JTextField regExit;
    private JTextField regSearch;
    private JTextField oldRegUpdate;
    private JTextField newRegUpdate;

    private JComboBox<String> typeBox;

    private JLabel freeSlotsValue;
    private JLabel occupiedSlotsValue;
    private JLabel revenueValue;
    private JLabel ticketLabel;

    private JTextArea adminArea;
    private JTextArea exitResultArea;
    private JTextArea searchResultArea;
    private JTextArea updateResultArea;

    private final Color BG = new Color(245, 248, 252);
    private final Color NAVY = new Color(18, 38, 63);
    private final Color TEAL = new Color(0, 150, 136);
    private final Color BLUE = new Color(33, 150, 243);
    private final Color PURPLE = new Color(63, 81, 181);
    private final Color ORANGE = new Color(255, 152, 0);
    private final Color RED = new Color(244, 67, 54);
    private final Color GRAY_BLUE = new Color(84, 110, 122);

    public ParkingUI() {
        setTitle("Smart Parking Management System");

        // Bigger window size
        setSize(1000, 700);
        setMinimumSize(new Dimension(950, 650));
        setLocationRelativeTo(null);
        setResizable(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        layout = new CardLayout();
        mainPanel = new JPanel(layout);

        mainPanel.add(homeScreen(), "home");
        mainPanel.add(parkScreen(), "park");
        mainPanel.add(searchScreen(), "search");
        mainPanel.add(updateScreen(), "update");
        mainPanel.add(exitScreen(), "exit");
        mainPanel.add(ticketScreen(), "ticket");
        mainPanel.add(adminScreen(), "admin");
        mainPanel.add(aboutScreen(), "about");

        add(mainPanel);
        setVisible(true);
    }

    private JPanel basePanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(85, 35, 25, 35));

        JLabel heading = new JLabel(title, SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 28));
        heading.setForeground(NAVY);

        panel.add(heading, BorderLayout.NORTH);
        return panel;
    }

    private JButton button(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(170, 45));
        return btn;
    }

   private JButton menuButton(String icon, String title, String subtitle, Color bgColor) {
    JButton btn = new JButton(title);

    btn.setFont(new Font("Segoe UI", Font.BOLD, 20));
    btn.setForeground(Color.WHITE);
    btn.setBackground(bgColor);
    btn.setFocusPainted(false);
    btn.setBorderPainted(false);
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

    btn.setHorizontalAlignment(SwingConstants.CENTER);
    btn.setVerticalAlignment(SwingConstants.CENTER);

    btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
    btn.setPreferredSize(new Dimension(400, 60));
    btn.setMinimumSize(new Dimension(350, 55));

    return btn;
}

    private JPanel card(String title, JLabel valueLabel, String subtitle, Color color) {
        JPanel card = new JPanel(new BorderLayout(15, 5));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 230, 235), 1),
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        titleLabel.setForeground(new Color(70, 80, 95));

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        valueLabel.setForeground(color);

        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(new Color(100, 110, 125));

        JPanel textPanel = new JPanel(new GridLayout(3, 1));
        textPanel.setBackground(Color.WHITE);
        textPanel.add(titleLabel);
        textPanel.add(valueLabel);
        textPanel.add(subtitleLabel);

        card.add(textPanel, BorderLayout.CENTER);
        return card;
    }

    private JTextField styledTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 17));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 220), 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        return field;
    }

    private JTextArea styledTextArea(int rows, int columns) {
        JTextArea area = new JTextArea(rows, columns);
        area.setFont(new Font("Consolas", Font.PLAIN, 15));
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        return area;
    }

    private void updateDashboard() {
        if (freeSlotsValue != null) {
            freeSlotsValue.setText(String.valueOf(system.getFreeSlots()));
            occupiedSlotsValue.setText(String.valueOf(system.getOccupiedSlots()));
            revenueValue.setText("Rs. " + system.getRevenue());
        }
    }

    private JPanel homeScreen() {
        JPanel panel = new JPanel(new BorderLayout(25, 25));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 25, 40));

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG);

        JLabel title = new JLabel("Parking Management System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 38));
        title.setForeground(NAVY);

        JLabel subtitle = new JLabel("Smart Parking Dashboard");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        subtitle.setForeground(new Color(90, 105, 125));

        JPanel titleBox = new JPanel(new GridLayout(2, 1));
        titleBox.setBackground(BG);
        titleBox.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 0));
        titleBox.add(title);
        titleBox.add(subtitle);

        JLabel logo = new JLabel("  P  ");
        logo.setOpaque(true);
        logo.setBackground(TEAL);
        logo.setForeground(Color.WHITE);
        logo.setFont(new Font("Segoe UI", Font.BOLD, 42));
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));


        header.add(logo, BorderLayout.WEST);
        header.add(titleBox, BorderLayout.CENTER);
        

        freeSlotsValue = new JLabel();
        occupiedSlotsValue = new JLabel();
        revenueValue = new JLabel();

        JPanel statsPanel = new JPanel(new GridLayout(1, 3, 25, 0));
        statsPanel.setBackground(BG);
        statsPanel.add(card("Free Slots", freeSlotsValue, "Available for parking", TEAL));
        statsPanel.add(card("Occupied Slots", occupiedSlotsValue, "Currently parked", BLUE));
        statsPanel.add(card("Revenue", revenueValue, "Total earnings", new Color(76, 175, 80)));

        JButton createBtn = menuButton("", "Park Vehicle", "Create / add new vehicle entry", TEAL);
        JButton readBtn = menuButton("", "Search Vehicle", "Search vehicle by registration number", BLUE);
        JButton updateBtn = menuButton("", "Update Vehicle", "Update vehicle registration details", PURPLE);
        JButton deleteBtn = menuButton("", "Exit Vehicle", "Remove vehicle and free the slot", ORANGE);
        JButton adminBtn = menuButton("", "Admin Panel", "View all parking slots", new Color(0, 121, 107));
        JButton aboutBtn = menuButton("", "About", "About this application", GRAY_BLUE);
        JButton quitBtn = menuButton("", "Quit", "", RED);
        quitBtn.setPreferredSize(new Dimension(900, 70));

        createBtn.addActionListener(e -> layout.show(mainPanel, "park"));
        readBtn.addActionListener(e -> layout.show(mainPanel, "search"));
        updateBtn.addActionListener(e -> layout.show(mainPanel, "update"));
        deleteBtn.addActionListener(e -> layout.show(mainPanel, "exit"));

        adminBtn.addActionListener(e -> {
            adminArea.setText(system.getStatus());
            layout.show(mainPanel, "admin");
        });

        aboutBtn.addActionListener(e -> layout.show(mainPanel, "about"));
        quitBtn.addActionListener(e -> System.exit(0));

        JPanel buttonGrid = new JPanel(new GridLayout(3, 2, 22, 16));
        buttonGrid.setPreferredSize(new Dimension(900, 275));
        buttonGrid.setBackground(Color.WHITE);
        buttonGrid.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 230, 235), 1),
                BorderFactory.createEmptyBorder(18, 20, 18, 20)
        ));

        buttonGrid.add(createBtn);
        buttonGrid.add(readBtn);
        buttonGrid.add(updateBtn);
        buttonGrid.add(deleteBtn);
        buttonGrid.add(adminBtn);
        buttonGrid.add(aboutBtn);

        JPanel center = new JPanel(new BorderLayout(20, 20));
        center.setBackground(BG);
        center.add(statsPanel, BorderLayout.NORTH);
        center.add(buttonGrid, BorderLayout.CENTER);
        JPanel quitPanel = new JPanel(new BorderLayout());
quitPanel.setBackground(BG);
quitPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

quitBtn.setPreferredSize(new Dimension(900, 60));

quitPanel.add(quitBtn, BorderLayout.CENTER);
center.add(quitPanel, BorderLayout.SOUTH);
        
        
        panel.add(header, BorderLayout.NORTH);
        panel.add(center, BorderLayout.CENTER);
    

        updateDashboard();
        return panel;
    }

private JPanel parkScreen() {
    JPanel panel = basePanel("Park Vehicle");

    JPanel card = new JPanel(new GridBagLayout());
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 230, 235), 1),
            BorderFactory.createEmptyBorder(35, 45, 35, 45)
    ));

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.weightx = 1;

    JLabel regLabel = new JLabel("Enter Registration Number");
    regLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    regLabel.setForeground(NAVY);

    regEntry = styledTextField();
    regEntry.setPreferredSize(new Dimension(420, 45));

    JLabel typeLabel = new JLabel("Select Vehicle Type");
    typeLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    typeLabel.setForeground(NAVY);

    typeBox = new JComboBox<>(new String[]{"Car", "Bike"});
    typeBox.setFont(new Font("Segoe UI", Font.PLAIN, 16));
    typeBox.setPreferredSize(new Dimension(420, 45));
    typeBox.setBackground(Color.WHITE);

    JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
    resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
    resultLabel.setForeground(RED);

    JButton parkBtn = button("Park Vehicle");
    parkBtn.setBackground(TEAL);
    parkBtn.setForeground(Color.WHITE);
    parkBtn.setPreferredSize(new Dimension(420, 50));

    JButton backBtn = button("Back");
    backBtn.setBackground(GRAY_BLUE);
    backBtn.setForeground(Color.WHITE);
    backBtn.setPreferredSize(new Dimension(420, 50));

    parkBtn.addActionListener(e -> {
        String regNo = regEntry.getText().trim();

        if (regNo.isEmpty()) {
            resultLabel.setText("Please enter registration number");
            return;
        }

        Vehicle vehicle;

        if (typeBox.getSelectedItem().equals("Car")) {
            vehicle = new Car(regNo);
        } else {
            vehicle = new Bike(regNo);
        }

        String result = system.parkVehicle(vehicle);
        resultLabel.setText(result);

        if (result.startsWith("Vehicle parked")) {
            ticketLabel.setText(
                    "<html><center>"
                            + "<h2>Ticket Generated Successfully</h2>"
                            + "Registration No: " + vehicle.getRegNo() + "<br>"
                            + "Vehicle Type: " + vehicle.getType() + "<br>"
                            + result
                            + "</center></html>"
            );

            regEntry.setText("");
            updateDashboard();
            layout.show(mainPanel, "ticket");
        }
    });

    backBtn.addActionListener(e -> {
        updateDashboard();
        layout.show(mainPanel, "home");
    });

    gbc.gridy = 0;
    card.add(regLabel, gbc);

    gbc.gridy = 1;
    card.add(regEntry, gbc);

    gbc.gridy = 2;
    card.add(typeLabel, gbc);

    gbc.gridy = 3;
    card.add(typeBox, gbc);

    gbc.gridy = 4;
    card.add(parkBtn, gbc);

    gbc.gridy = 5;
    card.add(resultLabel, gbc);

    gbc.gridy = 6;
    card.add(backBtn, gbc);

    JPanel wrapper = new JPanel(new GridBagLayout());
    wrapper.setBackground(BG);
    wrapper.add(card);

    panel.add(wrapper, BorderLayout.CENTER);

    return panel;
}

private JPanel searchScreen() {
    JPanel panel = basePanel("Search Vehicle");

    JPanel card = new JPanel(new GridBagLayout());
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 230, 235), 1),
            BorderFactory.createEmptyBorder(35, 45, 35, 45)
    ));

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.weightx = 1;

    JLabel regLabel = new JLabel("Enter Registration Number");
    regLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    regLabel.setForeground(NAVY);

    regSearch = styledTextField();
    regSearch.setPreferredSize(new Dimension(420, 45));

    JButton searchBtn = button("Search Vehicle");
    searchBtn.setBackground(BLUE);
    searchBtn.setForeground(Color.WHITE);
    searchBtn.setPreferredSize(new Dimension(420, 50));

    searchResultArea = styledTextArea(8, 30);
    searchResultArea.setFont(new Font("Segoe UI", Font.PLAIN, 15));
    searchResultArea.setBackground(Color.WHITE);

    JScrollPane resultScroll = new JScrollPane(searchResultArea);
    resultScroll.setPreferredSize(new Dimension(420, 150));
    resultScroll.setBorder(BorderFactory.createLineBorder(new Color(180, 195, 210), 1));

    JButton backBtn = button("Back");
    backBtn.setBackground(GRAY_BLUE);
    backBtn.setForeground(Color.WHITE);
    backBtn.setPreferredSize(new Dimension(420, 50));

    searchBtn.addActionListener(e -> {
        searchResultArea.setText(system.searchVehicle(regSearch.getText()));
    });

    backBtn.addActionListener(e -> {
        updateDashboard();
        layout.show(mainPanel, "home");
    });

    gbc.gridy = 0;
    card.add(regLabel, gbc);

    gbc.gridy = 1;
    card.add(regSearch, gbc);

    gbc.gridy = 2;
    card.add(searchBtn, gbc);

    gbc.gridy = 3;
    card.add(resultScroll, gbc);

    gbc.gridy = 4;
    card.add(backBtn, gbc);

    JPanel wrapper = new JPanel(new GridBagLayout());
    wrapper.setBackground(BG);
    wrapper.add(card);

    panel.add(wrapper, BorderLayout.CENTER);

    return panel;
}

    private JPanel updateScreen() {
    JPanel panel = basePanel("Update Vehicle");

    JPanel card = new JPanel(new GridLayout(7, 1, 12, 12));
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 230, 235), 1),
            BorderFactory.createEmptyBorder(35, 45, 35, 45)
    ));

    // Fixed card size like Park Vehicle screen
    card.setPreferredSize(new Dimension(560, 440));

    JLabel oldLabel = new JLabel("Enter Old Registration Number:");
    oldLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    oldLabel.setForeground(NAVY);

    oldRegUpdate = styledTextField();

    JLabel newLabel = new JLabel("Enter New Registration Number:");
    newLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    newLabel.setForeground(NAVY);

    newRegUpdate = styledTextField();

    JButton updateBtn = button("Update Vehicle");
    updateBtn.setBackground(PURPLE);
    updateBtn.setForeground(Color.WHITE);

    JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
    resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
    resultLabel.setForeground(NAVY);

    JButton backBtn = button("Back");
    backBtn.setBackground(GRAY_BLUE);
    backBtn.setForeground(Color.WHITE);

    updateBtn.addActionListener(e -> {
        String result = system.updateVehicleRegNo(
                oldRegUpdate.getText(),
                newRegUpdate.getText()
        );

        resultLabel.setText(result);

        if (result.equals("Registration number updated successfully")) {
            oldRegUpdate.setText("");
            newRegUpdate.setText("");
            resultLabel.setForeground(new Color(0, 150, 136));
        } else {
            resultLabel.setForeground(RED);
        }

        updateDashboard();
    });

    backBtn.addActionListener(e -> {
        updateDashboard();
        layout.show(mainPanel, "home");
    });

    card.add(oldLabel);
    card.add(oldRegUpdate);
    card.add(newLabel);
    card.add(newRegUpdate);
    card.add(updateBtn);
    card.add(resultLabel);
    card.add(backBtn);

    JPanel wrapper = new JPanel(new GridBagLayout());
    wrapper.setBackground(BG);
    wrapper.add(card);

    panel.add(wrapper, BorderLayout.CENTER);

    return panel;
}
    private JPanel exitScreen() {
    JPanel panel = basePanel("Exit Vehicle");

    JPanel card = new JPanel(new GridLayout(5, 1, 12, 12));
    card.setBackground(Color.WHITE);
    card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 230, 235), 1),
            BorderFactory.createEmptyBorder(35, 45, 35, 45)
    ));

    card.setPreferredSize(new Dimension(560, 330));

    JLabel regLabel = new JLabel("Enter Registration Number:");
    regLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
    regLabel.setForeground(NAVY);

    regExit = styledTextField();

    JButton exitBtn = button("Exit Vehicle");
    exitBtn.setBackground(ORANGE);
    exitBtn.setForeground(Color.WHITE);

    JLabel resultLabel = new JLabel("", SwingConstants.CENTER);
    resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
    resultLabel.setForeground(NAVY);

    JButton backBtn = button("Back");
    backBtn.setBackground(GRAY_BLUE);
    backBtn.setForeground(Color.WHITE);

    exitBtn.addActionListener(e -> {
        String result = system.exitVehicle(regExit.getText());

        resultLabel.setText("<html><center>" + result.replace("\n", "<br>") + "</center></html>");

        if (result.startsWith("Vehicle Exited")) {
            regExit.setText("");
            resultLabel.setForeground(new Color(0, 150, 136));
        } else {
            resultLabel.setForeground(RED);
        }

        updateDashboard();
    });

    backBtn.addActionListener(e -> {
        updateDashboard();
        layout.show(mainPanel, "home");
    });

    card.add(regLabel);
    card.add(regExit);
    card.add(exitBtn);
    card.add(resultLabel);
    card.add(backBtn);

    JPanel wrapper = new JPanel(new GridBagLayout());
    wrapper.setBackground(BG);
    wrapper.add(card);

    panel.add(wrapper, BorderLayout.CENTER);

    return panel;
}

    private JPanel ticketScreen() {
        JPanel panel = basePanel("Parking Ticket");

        ticketLabel = new JLabel("Ticket", SwingConstants.CENTER);
        ticketLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        ticketLabel.setForeground(NAVY);

        JButton doneBtn = button("Done");
        doneBtn.setBackground(TEAL);
        doneBtn.setForeground(Color.WHITE);

        doneBtn.addActionListener(e -> {
            updateDashboard();
            layout.show(mainPanel, "home");
        });

        panel.add(ticketLabel, BorderLayout.CENTER);
        panel.add(doneBtn, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel adminScreen() {
        JPanel panel = basePanel("Admin Panel - All Parking Slots");

        adminArea = styledTextArea(15, 45);
        adminArea.setFont(new Font("Consolas", Font.BOLD, 15));

        JButton refreshBtn = button("Refresh");
        refreshBtn.setBackground(BLUE);
        refreshBtn.setForeground(Color.WHITE);

        JButton backBtn = button("Back");
        backBtn.setBackground(GRAY_BLUE);
        backBtn.setForeground(Color.WHITE);

        refreshBtn.addActionListener(e -> adminArea.setText(system.getStatus()));

        backBtn.addActionListener(e -> {
            updateDashboard();
            layout.show(mainPanel, "home");
        });

        JPanel buttons = new JPanel();
        buttons.setBackground(BG);
        buttons.add(refreshBtn);
        buttons.add(backBtn);

        panel.add(new JScrollPane(adminArea), BorderLayout.CENTER);
        panel.add(buttons, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel aboutScreen() {
        JPanel panel = basePanel("About CRUD Project");

        JTextArea info = styledTextArea(15, 45);

        info.setText(
                "Smart Parking Management System\n\n"
                        + "CRUD Operations:\n\n"
                        + "CREATE:\n"
                        + "- Park Vehicle button se new vehicle add hoti hai.\n\n"
                        + "READ:\n"
                        + "- Search Vehicle se vehicle details read hoti hain.\n"
                        + "- Admin Panel se all slots ka status read hota hai.\n\n"
                        + "UPDATE:\n"
                        + "- Update Vehicle screen se registration number update hota hai.\n\n"
                        + "DELETE:\n"
                        + "- Exit Vehicle screen se vehicle parking se remove hoti hai.\n\n"
                        + "Fee Rules:\n"
                        + "Car: Rs. 100 per hour\n"
                        + "Bike: Rs. 50 per hour\n"
                        + "Minimum fee is for 1 hour."
        );

        JButton backBtn = button("Back");
        backBtn.setBackground(GRAY_BLUE);
        backBtn.setForeground(Color.WHITE);

        backBtn.addActionListener(e -> {
            updateDashboard();
            layout.show(mainPanel, "home");
        });

        panel.add(new JScrollPane(info), BorderLayout.CENTER);
        panel.add(backBtn, BorderLayout.SOUTH);

        return panel;
    }
}